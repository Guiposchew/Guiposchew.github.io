# Guilherme Schewtschik - Physics Portfolio

## Design Strategy: Academic Elegance

### Chosen Approach: **Academic Elegance**
Um design que reflete a excelência acadêmica e a sofisticação científica. O site comunica profissionalismo, rigor intelectual e acesso fácil aos trabalhos de pesquisa.

---

## Design Philosophy

**Design Movement:** Modernismo Acadêmico — inspirado em revistas científicas premium e portfólios de pesquisadores, com tipografia refinada, espaçamento generoso e hierarquia clara.

**Core Principles:**
1. **Clareza Intelectual** — Informações organizadas com precisão, sem ruído visual
2. **Elegância Discreta** — Sofisticação através de tipografia, espaçamento e cor, não de efeitos
3. **Acessibilidade Imediata** — PDFs e projetos encontráveis em segundos
4. **Profissionalismo Tangível** — Cada detalhe reforça credibilidade acadêmica

**Color Philosophy:**
- **Primária:** Azul profundo (`oklch(0.45 0.15 260)`) — confiança, inteligência, academia
- **Secundária:** Cinza quente (`oklch(0.95 0.002 70)`) — sofisticação, neutro elegante
- **Acentos:** Dourado suave (`oklch(0.75 0.08 70)`) — destaque refinado para CTAs e destaques
- **Fundo:** Branco puro com leve textura — clareza com profundidade

**Layout Paradigm:**
- Hero assimétrico com imagem/gradiente à direita
- Grid de 2-3 colunas para PDFs com cards elegantes
- Sidebar com navegação de projetos do GitHub
- Rodapé com links sociais e contato

**Signature Elements:**
1. **Linha divisória sutil** — Separadores minimalistas entre seções
2. **Cards com hover refinado** — Elevação suave, sombra discreta
3. **Tipografia em camadas** — Display bold + body regular para hierarquia

**Interaction Philosophy:**
- Transições suaves (200-300ms) ao interagir com cards
- Hover states que elevam sutilmente (sombra, cor)
- Animações de entrada em cascata para listas
- Sem animações desnecessárias — movimento tem propósito

**Animation:**
- Entrada de cards: fade + slide-up (300ms ease-out)
- Hover de links: underline animado (200ms)
- Transições de cor: suave (150ms)
- Respeita `prefers-reduced-motion`

**Typography System:**
- **Display:** Playfair Display (serif bold) — títulos principais, h1/h2
- **Heading:** Inter 600 — h3/h4, labels
- **Body:** Inter 400 — conteúdo, descrições
- **Mono:** JetBrains Mono — código, links técnicos
- **Hierarchy:** 3.5rem (h1) → 2.5rem (h2) → 1.5rem (h3) → 1rem (body)

**Brand Essence:**
*Um pesquisador de física em excelência acadêmica, compartilhando rigor científico através de trabalhos bem organizados.*
- **Personalidade:** Inteligente, Acessível, Rigoroso

**Brand Voice:**
- Headlines: Diretas, sem floreios. "Pesquisa em Física Quântica" em vez de "Bem-vindo ao meu portfólio"
- CTAs: Ação clara. "Baixar Relatório" em vez de "Clique aqui"
- Microcopy: Técnica mas clara. "Simulação Molecular — Dinâmica de Gases Ideais"

**Wordmark & Logo:**
- Símbolo: Onda senoidal estilizada + átomo minimalista (sem texto)
- Marca: Monograma "GS" em Playfair Display, azul profundo

**Signature Brand Color:**
- Azul Acadêmico: `oklch(0.45 0.15 260)` — imediatamente reconhecível, profissional, científico

---

## Visual Assets
- Hero background: Gradiente azul-cinza com padrão de ondas sutis
- Cards de PDFs: Ícones de documento, sombras refinadas
- Ícones do GitHub: Integração com GitHub API para exibir repos

---

## Implementation Notes
- Usar Tailwind 4 com cores customizadas em OKLCH
- Componentes shadcn/ui para consistência
- Responsivo: mobile-first, breakpoints em 640px, 1024px
- Acessibilidade: WCAG AA mínimo, focus rings visíveis
