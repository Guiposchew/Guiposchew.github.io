import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ExternalLink, Download, Github, Linkedin, Mail, BookOpen, Code2 } from "lucide-react";
import { useEffect, useState } from "react";

/**
 * Academic Elegance Design
 * - Deep blue primary color (oklch(0.45 0.15 260))
 * - Playfair Display for headings, Inter for body
 * - Generous whitespace and subtle shadows
 * - Elegant card-based layout for PDFs and projects
 */

interface GitHubRepo {
  name: string;
  description: string;
  url: string;
  language: string;
  stars: number;
}

const REPORTS = [
  {
    title: "Ideal Gas Law — Molecular Dynamics",
    description: "Molecular dynamics simulation exploring the ideal gas law through computational modeling.",
    url: "https://guiposchew.github.io/pdfs/ideal_gas.pdf",
    icon: "🔬",
  },
  {
    title: "Exploration into the Boundary Between Quantum and Classical Physics",
    description: "Investigation of the correspondence principle and the transition from quantum to classical mechanics.",
    url: "https://guiposchew.github.io/pdfs/Correspondence_Principle.pdf",
    icon: "⚛️",
  },
  {
    title: "Final Report from the Electronic Laboratories",
    description: "Comprehensive report from experimental electronics laboratory work and measurements.",
    url: "https://guiposchew.github.io/pdfs/Report_Electronic_Labs.pdf",
    icon: "🔌",
  },
  {
    title: "Merged Reports from the Computer Simulation II Course",
    description: "Compilation of all laboratory reports from the Computer Simulation II course.",
    url: "https://guiposchew.github.io/pdfs/All_reports_Comp_Sim_II.pdf",
    icon: "💻",
  },
  {
    title: "Final Summary Report for the Computer Simulation II Course",
    description: "Comprehensive summary and analysis of the Computer Simulation II course.",
    url: "https://guiposchew.github.io/pdfs/Report_Comp_Sim_II.pdf",
    icon: "📊",
  },
];

const FEATURED_PROJECTS: GitHubRepo[] = [
  {
    name: "Majorana Modes Machine",
    description: "Classical simulation pipeline for the 1D Kitaev chain — BdG spectra, Majorana edge modes, and topological invariants.",
    url: "https://github.com/Guiposchew/majorana-modes-machine",
    language: "Jupyter Notebook",
    stars: 0,
  },
  {
    name: "Computer-Based Physical Modelling",
    description: "Final project from the Computer Based Physical Modelling course at the International Physics Studies Program.",
    url: "https://github.com/Guiposchew/Computer-Based-Physical-Modelling-",
    language: "Jupyter Notebook",
    stars: 0,
  },
  {
    name: "Introduction to Computer Simulation I",
    description: "Course materials and projects from Introduction to Computer Simulation I at University of Leipzig.",
    url: "https://github.com/Guiposchew/Introduction-to-Computer-Simulation-I",
    language: "Python",
    stars: 0,
  },
];

export default function Home() {
  const [repos, setRepos] = useState<GitHubRepo[]>(FEATURED_PROJECTS);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    // Fetch GitHub repos data
    const fetchRepos = async () => {
      try {
        setIsLoading(true);
        const response = await fetch("https://api.github.com/users/Guiposchew/repos");
        const data = await response.json();
        
        // Filter and sort by updated date
        const filtered = data
          .filter((repo: any) => !repo.fork)
          .sort((a: any, b: any) => new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime())
          .slice(0, 6)
          .map((repo: any) => ({
            name: repo.name,
            description: repo.description || "No description available",
            url: repo.html_url,
            language: repo.language || "Unknown",
            stars: repo.stargazers_count,
          }));
        
        setRepos(filtered);
      } catch (error) {
        console.error("Failed to fetch repos:", error);
        setRepos(FEATURED_PROJECTS);
      } finally {
        setIsLoading(false);
      }
    };

    fetchRepos();
  }, []);

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation Header */}
      <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-sm border-b border-border shadow-sm">
        <div className="container flex items-center justify-between py-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-primary flex items-center justify-center">
              <img 
                src="/manus-storage/logo-symbol_59489fae.png" 
                alt="Logo" 
                className="w-6 h-6"
              />
            </div>
            <div className="flex flex-col">
              <h1 className="text-lg font-bold text-foreground">Guilherme Schewtschik</h1>
              <p className="text-xs text-muted-foreground">Physics Research</p>
            </div>
          </div>
          
          <nav className="hidden md:flex items-center gap-8">
            <a href="#reports" className="text-sm font-medium text-foreground hover:text-primary transition-colors">
              Reports
            </a>
            <a href="#projects" className="text-sm font-medium text-foreground hover:text-primary transition-colors">
              Projects
            </a>
            <div className="flex items-center gap-3">
              <a href="https://github.com/Guiposchew" target="_blank" rel="noopener noreferrer" className="p-2 hover:bg-secondary rounded-lg transition-colors">
                <Github className="w-5 h-5 text-foreground" />
              </a>
              <a href="https://linkedin.com/in/guilherme-schewtschik" target="_blank" rel="noopener noreferrer" className="p-2 hover:bg-secondary rounded-lg transition-colors">
                <Linkedin className="w-5 h-5 text-foreground" />
              </a>
              <a href="mailto:guilherme@example.com" className="p-2 hover:bg-secondary rounded-lg transition-colors">
                <Mail className="w-5 h-5 text-foreground" />
              </a>
            </div>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="container py-20 md:py-32">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <div className="space-y-3">
                <h2 className="text-sm font-semibold text-primary uppercase tracking-wider">
                  International Physics Studies Program
                </h2>
                <h1 className="text-5xl md:text-6xl font-bold text-foreground leading-tight">
                  Physics Research & Simulation
                </h1>
              </div>
              
              <p className="text-lg text-muted-foreground leading-relaxed max-w-lg">
                Student at the University of Leipzig, specializing in computational physics, quantum mechanics, and molecular dynamics simulations. Exploring the intersection of classical and quantum physics through rigorous research and simulation.
              </p>
              
              <div className="flex flex-wrap gap-3 pt-4">
                <a href="#reports">
                  <Button className="gap-2 bg-primary hover:bg-primary/90 text-white">
                    <BookOpen className="w-4 h-4" />
                    View Reports
                  </Button>
                </a>
                <a href="https://github.com/Guiposchew" target="_blank" rel="noopener noreferrer">
                  <Button variant="outline" className="gap-2">
                    <Github className="w-4 h-4" />
                    GitHub
                  </Button>
                </a>
              </div>
            </div>
            
            <div className="relative h-96 md:h-full rounded-xl overflow-hidden shadow-2xl">
              <img 
                src="/manus-storage/hero-background_3ce2bca2.png" 
                alt="Physics Background" 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
            </div>
          </div>
        </div>
      </section>

      {/* Reports Section */}
      <section id="reports" className="py-20 md:py-28 bg-secondary/30">
        <div className="container">
          <div className="mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
              Research Reports
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl">
              A collection of comprehensive research reports from my studies in physics, covering molecular dynamics, quantum mechanics, electronics, and computational simulations.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {REPORTS.map((report, idx) => (
              <Card 
                key={idx}
                className="group relative overflow-hidden hover:shadow-lg transition-all duration-300 hover:-translate-y-1 cursor-pointer"
              >
                <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-primary to-accent opacity-0 group-hover:opacity-100 transition-opacity" />
                
                <div className="p-6 space-y-4">
                  <div className="text-4xl">{report.icon}</div>
                  
                  <div className="space-y-2">
                    <h3 className="text-xl font-bold text-foreground group-hover:text-primary transition-colors">
                      {report.title}
                    </h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      {report.description}
                    </p>
                  </div>
                  
                  <a 
                    href={report.url} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 text-primary font-semibold hover:gap-3 transition-all"
                  >
                    <Download className="w-4 h-4" />
                    Download PDF
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* GitHub Projects Section */}
      <section id="projects" className="py-20 md:py-28">
        <div className="container">
          <div className="mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
              GitHub Projects
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl">
              Explore my open-source repositories featuring computational physics simulations, machine learning applications, and research implementations.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {repos.map((repo, idx) => (
              <a
                key={idx}
                href={repo.url}
                target="_blank"
                rel="noopener noreferrer"
                className="group"
              >
                <Card className="h-full hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
                  <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-primary to-accent opacity-0 group-hover:opacity-100 transition-opacity" />
                  
                  <div className="p-6 space-y-4 h-full flex flex-col">
                    <div className="flex items-start justify-between">
                      <Code2 className="w-8 h-8 text-primary" />
                      {repo.stars > 0 && (
                        <span className="text-xs font-semibold text-accent bg-accent/10 px-2 py-1 rounded">
                          ⭐ {repo.stars}
                        </span>
                      )}
                    </div>
                    
                    <div className="flex-1 space-y-2">
                      <h3 className="text-lg font-bold text-foreground group-hover:text-primary transition-colors">
                        {repo.name}
                      </h3>
                      <p className="text-sm text-muted-foreground leading-relaxed">
                        {repo.description}
                      </p>
                    </div>
                    
                    <div className="flex items-center justify-between pt-4 border-t border-border">
                      <span className="text-xs font-medium text-muted-foreground bg-muted px-2 py-1 rounded">
                        {repo.language}
                      </span>
                      <ExternalLink className="w-4 h-4 text-primary opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                  </div>
                </Card>
              </a>
            ))}
          </div>

          <div className="mt-12 text-center">
            <a href="https://github.com/Guiposchew" target="_blank" rel="noopener noreferrer">
              <Button variant="outline" size="lg" className="gap-2">
                <Github className="w-5 h-5" />
                View All Repositories
              </Button>
            </a>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 md:py-28 bg-primary text-white">
        <div className="container text-center space-y-8">
          <div className="space-y-4">
            <h2 className="text-4xl md:text-5xl font-bold">
              Let's Connect
            </h2>
            <p className="text-lg text-white/80 max-w-2xl mx-auto">
              Interested in discussing physics research, computational simulations, or collaboration opportunities? Feel free to reach out.
            </p>
          </div>

          <div className="flex flex-wrap justify-center gap-4 pt-8">
            <a href="https://github.com/Guiposchew" target="_blank" rel="noopener noreferrer">
              <Button variant="secondary" className="gap-2">
                <Github className="w-4 h-4" />
                GitHub
              </Button>
            </a>
            <a href="https://linkedin.com/in/guilherme-schewtschik" target="_blank" rel="noopener noreferrer">
              <Button variant="secondary" className="gap-2">
                <Linkedin className="w-4 h-4" />
                LinkedIn
              </Button>
            </a>
            <a href="mailto:guilherme@example.com">
              <Button variant="secondary" className="gap-2">
                <Mail className="w-4 h-4" />
                Email
              </Button>
            </a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-foreground/5 border-t border-border py-8">
        <div className="container">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-sm text-muted-foreground">
              © 2026 Guilherme Schewtschik. All rights reserved.
            </p>
            <p className="text-sm text-muted-foreground">
              International Physics Studies Program, University of Leipzig
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
